import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { ConfigModule, ConfigService } from '@nestjs/config';

import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { MailService } from '../utils/mail';
import { StorageService } from '../lib/storage.service';
import { JwtStrategy } from './guards/jtw.strategy';

@Module({
  imports: [
    ConfigModule, // 🔥 garante acesso ao env
    PassportModule,

    JwtModule.registerAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        secret: config.get<string>('JWT_SECRET'),
        signOptions: { expiresIn: '7d' },
      }),
    }),
  ],
  controllers: [AuthController],
  providers: [
    AuthService,
    MailService,
    StorageService,
    JwtStrategy
  ],
  exports: [
    AuthService,
    MailService,
    JwtModule
  ],
})
export class AuthModule {}